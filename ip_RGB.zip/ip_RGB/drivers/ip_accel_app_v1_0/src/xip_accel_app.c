// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xip_accel_app.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XIp_accel_app_CfgInitialize(XIp_accel_app *InstancePtr, XIp_accel_app_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XIp_accel_app_Start(XIp_accel_app *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_AP_CTRL) & 0x80;
    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_AP_CTRL, Data | 0x01);
}

u32 XIp_accel_app_IsDone(XIp_accel_app *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XIp_accel_app_IsIdle(XIp_accel_app *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XIp_accel_app_IsReady(XIp_accel_app *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XIp_accel_app_EnableAutoRestart(XIp_accel_app *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_AP_CTRL, 0x80);
}

void XIp_accel_app_DisableAutoRestart(XIp_accel_app *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_AP_CTRL, 0);
}

void XIp_accel_app_InterruptGlobalEnable(XIp_accel_app *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_GIE, 1);
}

void XIp_accel_app_InterruptGlobalDisable(XIp_accel_app *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_GIE, 0);
}

void XIp_accel_app_InterruptEnable(XIp_accel_app *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_IER);
    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_IER, Register | Mask);
}

void XIp_accel_app_InterruptDisable(XIp_accel_app *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_IER);
    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_IER, Register & (~Mask));
}

void XIp_accel_app_InterruptClear(XIp_accel_app *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIp_accel_app_WriteReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_ISR, Mask);
}

u32 XIp_accel_app_InterruptGetEnabled(XIp_accel_app *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_IER);
}

u32 XIp_accel_app_InterruptGetStatus(XIp_accel_app *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XIp_accel_app_ReadReg(InstancePtr->Axilites_BaseAddress, XIP_ACCEL_APP_AXILITES_ADDR_ISR);
}

