// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xip_accel_app.h"

extern XIp_accel_app_Config XIp_accel_app_ConfigTable[];

XIp_accel_app_Config *XIp_accel_app_LookupConfig(u16 DeviceId) {
	XIp_accel_app_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XIP_ACCEL_APP_NUM_INSTANCES; Index++) {
		if (XIp_accel_app_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XIp_accel_app_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XIp_accel_app_Initialize(XIp_accel_app *InstancePtr, u16 DeviceId) {
	XIp_accel_app_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XIp_accel_app_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XIp_accel_app_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

