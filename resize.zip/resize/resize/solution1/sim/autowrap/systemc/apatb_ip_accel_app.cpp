// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

#define AP_INT_MAX_W 32678

#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include <complex>
#include <stdbool.h>
#include "autopilot_cbe.h"
#include "hls_stream.h"
#include "hls_half.h"
#include "hls_signal_handler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;


// [dump_struct_tree [build_nameSpaceTree] dumpedStructList] ---------->
    template< int D ,int U ,int TI ,int TD > struct ap_axiu;
    template<> struct ap_axiu<24, 1, 1, 1> {
        ap_uint<24> data;
        ap_uint<3> keep;
        ap_uint<3> strb;
        ap_uint<1> user;
        ap_uint<1> last;
        ap_uint<1> id;
        ap_uint<1> dest;
       } ;



// [dump_enumeration [get_enumeration_list]] ---------->


// wrapc file define: "p_src_V_data_V"
#define AUTOTB_TVIN_p_src_V_data_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_src_V_data_V.dat"
#define WRAPC_STREAM_SIZE_IN_p_src_V_data_V  "../tv/stream_size/stream_size_in_p_src_V_data_V.dat"
#define WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V  "../tv/stream_size/stream_ingress_status_p_src_V_data_V.dat"
// wrapc file define: "p_src_V_keep_V"
#define AUTOTB_TVIN_p_src_V_keep_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_src_V_keep_V.dat"
#define WRAPC_STREAM_SIZE_IN_p_src_V_keep_V  "../tv/stream_size/stream_size_in_p_src_V_keep_V.dat"
#define WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V  "../tv/stream_size/stream_ingress_status_p_src_V_keep_V.dat"
// wrapc file define: "p_src_V_strb_V"
#define AUTOTB_TVIN_p_src_V_strb_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_src_V_strb_V.dat"
#define WRAPC_STREAM_SIZE_IN_p_src_V_strb_V  "../tv/stream_size/stream_size_in_p_src_V_strb_V.dat"
#define WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V  "../tv/stream_size/stream_ingress_status_p_src_V_strb_V.dat"
// wrapc file define: "p_src_V_user_V"
#define AUTOTB_TVIN_p_src_V_user_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_src_V_user_V.dat"
#define WRAPC_STREAM_SIZE_IN_p_src_V_user_V  "../tv/stream_size/stream_size_in_p_src_V_user_V.dat"
#define WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V  "../tv/stream_size/stream_ingress_status_p_src_V_user_V.dat"
// wrapc file define: "p_src_V_last_V"
#define AUTOTB_TVIN_p_src_V_last_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_src_V_last_V.dat"
#define WRAPC_STREAM_SIZE_IN_p_src_V_last_V  "../tv/stream_size/stream_size_in_p_src_V_last_V.dat"
#define WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V  "../tv/stream_size/stream_ingress_status_p_src_V_last_V.dat"
// wrapc file define: "p_src_V_id_V"
#define AUTOTB_TVIN_p_src_V_id_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_src_V_id_V.dat"
#define WRAPC_STREAM_SIZE_IN_p_src_V_id_V  "../tv/stream_size/stream_size_in_p_src_V_id_V.dat"
#define WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V  "../tv/stream_size/stream_ingress_status_p_src_V_id_V.dat"
// wrapc file define: "p_src_V_dest_V"
#define AUTOTB_TVIN_p_src_V_dest_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_src_V_dest_V.dat"
#define WRAPC_STREAM_SIZE_IN_p_src_V_dest_V  "../tv/stream_size/stream_size_in_p_src_V_dest_V.dat"
#define WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V  "../tv/stream_size/stream_ingress_status_p_src_V_dest_V.dat"
// wrapc file define: "p_dst_V_data_V"
#define AUTOTB_TVOUT_p_dst_V_data_V  "../tv/cdatafile/c.ip_accel_app.autotvout_p_dst_V_data_V.dat"
#define AUTOTB_TVIN_p_dst_V_data_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_dst_V_data_V.dat"
#define WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V  "../tv/stream_size/stream_size_out_p_dst_V_data_V.dat"
#define WRAPC_STREAM_EGRESS_STATUS_p_dst_V_data_V  "../tv/stream_size/stream_egress_status_p_dst_V_data_V.dat"
// wrapc file define: "p_dst_V_keep_V"
#define AUTOTB_TVOUT_p_dst_V_keep_V  "../tv/cdatafile/c.ip_accel_app.autotvout_p_dst_V_keep_V.dat"
#define AUTOTB_TVIN_p_dst_V_keep_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_dst_V_keep_V.dat"
#define WRAPC_STREAM_SIZE_OUT_p_dst_V_keep_V  "../tv/stream_size/stream_size_out_p_dst_V_keep_V.dat"
#define WRAPC_STREAM_EGRESS_STATUS_p_dst_V_keep_V  "../tv/stream_size/stream_egress_status_p_dst_V_keep_V.dat"
// wrapc file define: "p_dst_V_strb_V"
#define AUTOTB_TVOUT_p_dst_V_strb_V  "../tv/cdatafile/c.ip_accel_app.autotvout_p_dst_V_strb_V.dat"
#define AUTOTB_TVIN_p_dst_V_strb_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_dst_V_strb_V.dat"
#define WRAPC_STREAM_SIZE_OUT_p_dst_V_strb_V  "../tv/stream_size/stream_size_out_p_dst_V_strb_V.dat"
#define WRAPC_STREAM_EGRESS_STATUS_p_dst_V_strb_V  "../tv/stream_size/stream_egress_status_p_dst_V_strb_V.dat"
// wrapc file define: "p_dst_V_user_V"
#define AUTOTB_TVOUT_p_dst_V_user_V  "../tv/cdatafile/c.ip_accel_app.autotvout_p_dst_V_user_V.dat"
#define AUTOTB_TVIN_p_dst_V_user_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_dst_V_user_V.dat"
#define WRAPC_STREAM_SIZE_OUT_p_dst_V_user_V  "../tv/stream_size/stream_size_out_p_dst_V_user_V.dat"
#define WRAPC_STREAM_EGRESS_STATUS_p_dst_V_user_V  "../tv/stream_size/stream_egress_status_p_dst_V_user_V.dat"
// wrapc file define: "p_dst_V_last_V"
#define AUTOTB_TVOUT_p_dst_V_last_V  "../tv/cdatafile/c.ip_accel_app.autotvout_p_dst_V_last_V.dat"
#define AUTOTB_TVIN_p_dst_V_last_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_dst_V_last_V.dat"
#define WRAPC_STREAM_SIZE_OUT_p_dst_V_last_V  "../tv/stream_size/stream_size_out_p_dst_V_last_V.dat"
#define WRAPC_STREAM_EGRESS_STATUS_p_dst_V_last_V  "../tv/stream_size/stream_egress_status_p_dst_V_last_V.dat"
// wrapc file define: "p_dst_V_id_V"
#define AUTOTB_TVOUT_p_dst_V_id_V  "../tv/cdatafile/c.ip_accel_app.autotvout_p_dst_V_id_V.dat"
#define AUTOTB_TVIN_p_dst_V_id_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_dst_V_id_V.dat"
#define WRAPC_STREAM_SIZE_OUT_p_dst_V_id_V  "../tv/stream_size/stream_size_out_p_dst_V_id_V.dat"
#define WRAPC_STREAM_EGRESS_STATUS_p_dst_V_id_V  "../tv/stream_size/stream_egress_status_p_dst_V_id_V.dat"
// wrapc file define: "p_dst_V_dest_V"
#define AUTOTB_TVOUT_p_dst_V_dest_V  "../tv/cdatafile/c.ip_accel_app.autotvout_p_dst_V_dest_V.dat"
#define AUTOTB_TVIN_p_dst_V_dest_V  "../tv/cdatafile/c.ip_accel_app.autotvin_p_dst_V_dest_V.dat"
#define WRAPC_STREAM_SIZE_OUT_p_dst_V_dest_V  "../tv/stream_size/stream_size_out_p_dst_V_dest_V.dat"
#define WRAPC_STREAM_EGRESS_STATUS_p_dst_V_dest_V  "../tv/stream_size/stream_egress_status_p_dst_V_dest_V.dat"
// wrapc file define: "src_height"
#define AUTOTB_TVIN_src_height  "../tv/cdatafile/c.ip_accel_app.autotvin_src_height.dat"
// wrapc file define: "src_width"
#define AUTOTB_TVIN_src_width  "../tv/cdatafile/c.ip_accel_app.autotvin_src_width.dat"
// wrapc file define: "dst_height"
#define AUTOTB_TVIN_dst_height  "../tv/cdatafile/c.ip_accel_app.autotvin_dst_height.dat"
// wrapc file define: "dst_width"
#define AUTOTB_TVIN_dst_width  "../tv/cdatafile/c.ip_accel_app.autotvin_dst_width.dat"

#define INTER_TCL  "../tv/cdatafile/ref.tcl"

// tvout file define: "p_dst_V_data_V"
#define AUTOTB_TVOUT_PC_p_dst_V_data_V  "../tv/rtldatafile/rtl.ip_accel_app.autotvout_p_dst_V_data_V.dat"
// tvout file define: "p_dst_V_keep_V"
#define AUTOTB_TVOUT_PC_p_dst_V_keep_V  "../tv/rtldatafile/rtl.ip_accel_app.autotvout_p_dst_V_keep_V.dat"
// tvout file define: "p_dst_V_strb_V"
#define AUTOTB_TVOUT_PC_p_dst_V_strb_V  "../tv/rtldatafile/rtl.ip_accel_app.autotvout_p_dst_V_strb_V.dat"
// tvout file define: "p_dst_V_user_V"
#define AUTOTB_TVOUT_PC_p_dst_V_user_V  "../tv/rtldatafile/rtl.ip_accel_app.autotvout_p_dst_V_user_V.dat"
// tvout file define: "p_dst_V_last_V"
#define AUTOTB_TVOUT_PC_p_dst_V_last_V  "../tv/rtldatafile/rtl.ip_accel_app.autotvout_p_dst_V_last_V.dat"
// tvout file define: "p_dst_V_id_V"
#define AUTOTB_TVOUT_PC_p_dst_V_id_V  "../tv/rtldatafile/rtl.ip_accel_app.autotvout_p_dst_V_id_V.dat"
// tvout file define: "p_dst_V_dest_V"
#define AUTOTB_TVOUT_PC_p_dst_V_dest_V  "../tv/rtldatafile/rtl.ip_accel_app.autotvout_p_dst_V_dest_V.dat"

class INTER_TCL_FILE {
	public:
		INTER_TCL_FILE(const char* name) {
			mName = name;
			p_src_V_data_V_depth = 0;
			p_src_V_keep_V_depth = 0;
			p_src_V_strb_V_depth = 0;
			p_src_V_user_V_depth = 0;
			p_src_V_last_V_depth = 0;
			p_src_V_id_V_depth = 0;
			p_src_V_dest_V_depth = 0;
			p_dst_V_data_V_depth = 0;
			p_dst_V_keep_V_depth = 0;
			p_dst_V_strb_V_depth = 0;
			p_dst_V_user_V_depth = 0;
			p_dst_V_last_V_depth = 0;
			p_dst_V_id_V_depth = 0;
			p_dst_V_dest_V_depth = 0;
			src_height_depth = 0;
			src_width_depth = 0;
			dst_height_depth = 0;
			dst_width_depth = 0;
			trans_num =0;
		}

		~INTER_TCL_FILE() {
			mFile.open(mName);
			if (!mFile.good()) {
				cout << "Failed to open file ref.tcl" << endl;
				exit (1);
			}
			string total_list = get_depth_list();
			mFile << "set depth_list {\n";
			mFile << total_list;
			mFile << "}\n";
			mFile << "set trans_num "<<trans_num<<endl;
			mFile.close();
		}

		string get_depth_list () {
			stringstream total_list;
			total_list << "{p_src_V_data_V " << p_src_V_data_V_depth << "}\n";
			total_list << "{p_src_V_keep_V " << p_src_V_keep_V_depth << "}\n";
			total_list << "{p_src_V_strb_V " << p_src_V_strb_V_depth << "}\n";
			total_list << "{p_src_V_user_V " << p_src_V_user_V_depth << "}\n";
			total_list << "{p_src_V_last_V " << p_src_V_last_V_depth << "}\n";
			total_list << "{p_src_V_id_V " << p_src_V_id_V_depth << "}\n";
			total_list << "{p_src_V_dest_V " << p_src_V_dest_V_depth << "}\n";
			total_list << "{p_dst_V_data_V " << p_dst_V_data_V_depth << "}\n";
			total_list << "{p_dst_V_keep_V " << p_dst_V_keep_V_depth << "}\n";
			total_list << "{p_dst_V_strb_V " << p_dst_V_strb_V_depth << "}\n";
			total_list << "{p_dst_V_user_V " << p_dst_V_user_V_depth << "}\n";
			total_list << "{p_dst_V_last_V " << p_dst_V_last_V_depth << "}\n";
			total_list << "{p_dst_V_id_V " << p_dst_V_id_V_depth << "}\n";
			total_list << "{p_dst_V_dest_V " << p_dst_V_dest_V_depth << "}\n";
			total_list << "{src_height " << src_height_depth << "}\n";
			total_list << "{src_width " << src_width_depth << "}\n";
			total_list << "{dst_height " << dst_height_depth << "}\n";
			total_list << "{dst_width " << dst_width_depth << "}\n";
			return total_list.str();
		}

		void set_num (int num , int* class_num) {
			(*class_num) = (*class_num) > num ? (*class_num) : num;
		}
	public:
		int p_src_V_data_V_depth;
		int p_src_V_keep_V_depth;
		int p_src_V_strb_V_depth;
		int p_src_V_user_V_depth;
		int p_src_V_last_V_depth;
		int p_src_V_id_V_depth;
		int p_src_V_dest_V_depth;
		int p_dst_V_data_V_depth;
		int p_dst_V_keep_V_depth;
		int p_dst_V_strb_V_depth;
		int p_dst_V_user_V_depth;
		int p_dst_V_last_V_depth;
		int p_dst_V_id_V_depth;
		int p_dst_V_dest_V_depth;
		int src_height_depth;
		int src_width_depth;
		int dst_height_depth;
		int dst_width_depth;
		int trans_num;

	private:
		ofstream mFile;
		const char* mName;
};

extern void ip_accel_app (
hls::stream<ap_axiu<24, 1, 1, 1 > > (&_src),
hls::stream<ap_axiu<24, 1, 1, 1 > > (&_dst),
int src_height,
int src_width,
int dst_height,
int dst_width);

void AESL_WRAP_ip_accel_app (
hls::stream<ap_axiu<24, 1, 1, 1 > > (&_src),
hls::stream<ap_axiu<24, 1, 1, 1 > > (&_dst),
int src_height,
int src_width,
int dst_height,
int dst_width)
{
	refine_signal_handler();
	fstream wrapc_switch_file_token;
	wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");
	int AESL_i;
	if (wrapc_switch_file_token.good())
	{
		CodeState = ENTER_WRAPC_PC;
		static unsigned AESL_transaction_pc = 0;
		string AESL_token;
		string AESL_num;
		static AESL_FILE_HANDLER aesl_fh;

		// pop stream input: "_src"
		aesl_fh.read(WRAPC_STREAM_SIZE_IN_p_src_V_data_V, AESL_token); // [[transaction]]
		aesl_fh.read(WRAPC_STREAM_SIZE_IN_p_src_V_data_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(WRAPC_STREAM_SIZE_IN_p_src_V_data_V, AESL_token); // pop_size
			int aesl_tmp_1 = atoi(AESL_token.c_str());
			for (int i = 0; i < aesl_tmp_1; i++)
			{
				_src.read();
			}
			aesl_fh.read(WRAPC_STREAM_SIZE_IN_p_src_V_data_V, AESL_token); // [[/transaction]]
		}

		// define output stream variables: "_dst"
		std::vector<ap_axiu<24, 1, 1, 1 > > aesl_tmp_3;
		int aesl_tmp_4;
		int aesl_tmp_5 = 0;

		// read output stream size: "_dst"
		aesl_fh.read(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V, AESL_token); // [[transaction]]
		aesl_fh.read(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V, AESL_token); // pop_size
			aesl_tmp_4 = atoi(AESL_token.c_str());
			aesl_fh.read(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V, AESL_token); // [[/transaction]]
		}

		// output port post check: "p_dst_V_data_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_data_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_data_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_data_V, AESL_token); // data

			std::vector<sc_bv<24> > p_dst_V_data_V_pc_buffer;
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_data_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_data_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					p_dst_V_data_V_pc_buffer.push_back(AESL_token.c_str());
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_data_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_p_dst_V_data_V))
				{
					exit(1);
				}
			}

			// correct the buffer size the current transaction
			if (i != aesl_tmp_4)
			{
				aesl_tmp_4 = i;
			}

			if (aesl_tmp_4 > 0 && aesl_tmp_3.size() < aesl_tmp_4)
			{
				int aesl_tmp_3_size = aesl_tmp_3.size();

				for (int tmp_aesl_tmp_3 = 0; tmp_aesl_tmp_3 < aesl_tmp_4 - aesl_tmp_3_size; tmp_aesl_tmp_3++)
				{
					ap_axiu<24, 1, 1, 1 > tmp;
					aesl_tmp_3.push_back(tmp);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: p_dst_V_data_V
				{
					// bitslice(23, 0)
					// {
						// celement: _dst.V.data.V(23, 0)
						// {
							sc_lv<24>* _dst_V_data_V_lv0_0_0_1_lv1_0_0_1 = new sc_lv<24>[aesl_tmp_4 - aesl_tmp_5];
						// }
					// }

					// bitslice(23, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.data.V(23, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									if (&(aesl_tmp_3[0].data) != NULL) // check the null address if the c port is array or others
									{
										_dst_V_data_V_lv0_0_0_1_lv1_0_0_1[hls_map_index].range(23, 0) = sc_bv<24>(p_dst_V_data_V_pc_buffer[hls_map_index].range(23, 0));
										hls_map_index++;
									}
								}
							}
						}
					}

					// bitslice(23, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.data.V(23, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									// sub                    : i_0 i_1
									// ori_name               : aesl_tmp_3[i_0].data
									// sub_1st_elem           : 0 0
									// ori_name_1st_elem      : aesl_tmp_3[0].data
									// output_left_conversion : aesl_tmp_3[i_0].data
									// output_type_conversion : (_dst_V_data_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str()
									if (&(aesl_tmp_3[0].data) != NULL) // check the null address if the c port is array or others
									{
										aesl_tmp_3[i_0].data = (_dst_V_data_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str();
										hls_map_index++;
									}
								}
							}
						}
					}
				}
			}
		}

		// output port post check: "p_dst_V_keep_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_keep_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_keep_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_keep_V, AESL_token); // data

			std::vector<sc_bv<3> > p_dst_V_keep_V_pc_buffer;
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_keep_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_keep_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					p_dst_V_keep_V_pc_buffer.push_back(AESL_token.c_str());
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_keep_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_p_dst_V_keep_V))
				{
					exit(1);
				}
			}

			// correct the buffer size the current transaction
			if (i != aesl_tmp_4)
			{
				aesl_tmp_4 = i;
			}

			if (aesl_tmp_4 > 0 && aesl_tmp_3.size() < aesl_tmp_4)
			{
				int aesl_tmp_3_size = aesl_tmp_3.size();

				for (int tmp_aesl_tmp_3 = 0; tmp_aesl_tmp_3 < aesl_tmp_4 - aesl_tmp_3_size; tmp_aesl_tmp_3++)
				{
					ap_axiu<24, 1, 1, 1 > tmp;
					aesl_tmp_3.push_back(tmp);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: p_dst_V_keep_V
				{
					// bitslice(2, 0)
					// {
						// celement: _dst.V.keep.V(2, 0)
						// {
							sc_lv<3>* _dst_V_keep_V_lv0_0_0_1_lv1_0_0_1 = new sc_lv<3>[aesl_tmp_4 - aesl_tmp_5];
						// }
					// }

					// bitslice(2, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.keep.V(2, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									if (&(aesl_tmp_3[0].keep) != NULL) // check the null address if the c port is array or others
									{
										_dst_V_keep_V_lv0_0_0_1_lv1_0_0_1[hls_map_index].range(2, 0) = sc_bv<3>(p_dst_V_keep_V_pc_buffer[hls_map_index].range(2, 0));
										hls_map_index++;
									}
								}
							}
						}
					}

					// bitslice(2, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.keep.V(2, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									// sub                    : i_0 i_1
									// ori_name               : aesl_tmp_3[i_0].keep
									// sub_1st_elem           : 0 0
									// ori_name_1st_elem      : aesl_tmp_3[0].keep
									// output_left_conversion : aesl_tmp_3[i_0].keep
									// output_type_conversion : (_dst_V_keep_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str()
									if (&(aesl_tmp_3[0].keep) != NULL) // check the null address if the c port is array or others
									{
										aesl_tmp_3[i_0].keep = (_dst_V_keep_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str();
										hls_map_index++;
									}
								}
							}
						}
					}
				}
			}
		}

		// output port post check: "p_dst_V_strb_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_strb_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_strb_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_strb_V, AESL_token); // data

			std::vector<sc_bv<3> > p_dst_V_strb_V_pc_buffer;
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_strb_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_strb_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					p_dst_V_strb_V_pc_buffer.push_back(AESL_token.c_str());
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_strb_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_p_dst_V_strb_V))
				{
					exit(1);
				}
			}

			// correct the buffer size the current transaction
			if (i != aesl_tmp_4)
			{
				aesl_tmp_4 = i;
			}

			if (aesl_tmp_4 > 0 && aesl_tmp_3.size() < aesl_tmp_4)
			{
				int aesl_tmp_3_size = aesl_tmp_3.size();

				for (int tmp_aesl_tmp_3 = 0; tmp_aesl_tmp_3 < aesl_tmp_4 - aesl_tmp_3_size; tmp_aesl_tmp_3++)
				{
					ap_axiu<24, 1, 1, 1 > tmp;
					aesl_tmp_3.push_back(tmp);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: p_dst_V_strb_V
				{
					// bitslice(2, 0)
					// {
						// celement: _dst.V.strb.V(2, 0)
						// {
							sc_lv<3>* _dst_V_strb_V_lv0_0_0_1_lv1_0_0_1 = new sc_lv<3>[aesl_tmp_4 - aesl_tmp_5];
						// }
					// }

					// bitslice(2, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.strb.V(2, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									if (&(aesl_tmp_3[0].strb) != NULL) // check the null address if the c port is array or others
									{
										_dst_V_strb_V_lv0_0_0_1_lv1_0_0_1[hls_map_index].range(2, 0) = sc_bv<3>(p_dst_V_strb_V_pc_buffer[hls_map_index].range(2, 0));
										hls_map_index++;
									}
								}
							}
						}
					}

					// bitslice(2, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.strb.V(2, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									// sub                    : i_0 i_1
									// ori_name               : aesl_tmp_3[i_0].strb
									// sub_1st_elem           : 0 0
									// ori_name_1st_elem      : aesl_tmp_3[0].strb
									// output_left_conversion : aesl_tmp_3[i_0].strb
									// output_type_conversion : (_dst_V_strb_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str()
									if (&(aesl_tmp_3[0].strb) != NULL) // check the null address if the c port is array or others
									{
										aesl_tmp_3[i_0].strb = (_dst_V_strb_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str();
										hls_map_index++;
									}
								}
							}
						}
					}
				}
			}
		}

		// output port post check: "p_dst_V_user_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_user_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_user_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_user_V, AESL_token); // data

			std::vector<sc_bv<1> > p_dst_V_user_V_pc_buffer;
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_user_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_user_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					p_dst_V_user_V_pc_buffer.push_back(AESL_token.c_str());
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_user_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_p_dst_V_user_V))
				{
					exit(1);
				}
			}

			// correct the buffer size the current transaction
			if (i != aesl_tmp_4)
			{
				aesl_tmp_4 = i;
			}

			if (aesl_tmp_4 > 0 && aesl_tmp_3.size() < aesl_tmp_4)
			{
				int aesl_tmp_3_size = aesl_tmp_3.size();

				for (int tmp_aesl_tmp_3 = 0; tmp_aesl_tmp_3 < aesl_tmp_4 - aesl_tmp_3_size; tmp_aesl_tmp_3++)
				{
					ap_axiu<24, 1, 1, 1 > tmp;
					aesl_tmp_3.push_back(tmp);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: p_dst_V_user_V
				{
					// bitslice(0, 0)
					// {
						// celement: _dst.V.user.V(0, 0)
						// {
							sc_lv<1>* _dst_V_user_V_lv0_0_0_1_lv1_0_0_1 = new sc_lv<1>[aesl_tmp_4 - aesl_tmp_5];
						// }
					// }

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.user.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									if (&(aesl_tmp_3[0].user) != NULL) // check the null address if the c port is array or others
									{
										_dst_V_user_V_lv0_0_0_1_lv1_0_0_1[hls_map_index].range(0, 0) = sc_bv<1>(p_dst_V_user_V_pc_buffer[hls_map_index].range(0, 0));
										hls_map_index++;
									}
								}
							}
						}
					}

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.user.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									// sub                    : i_0 i_1
									// ori_name               : aesl_tmp_3[i_0].user
									// sub_1st_elem           : 0 0
									// ori_name_1st_elem      : aesl_tmp_3[0].user
									// output_left_conversion : aesl_tmp_3[i_0].user
									// output_type_conversion : (_dst_V_user_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str()
									if (&(aesl_tmp_3[0].user) != NULL) // check the null address if the c port is array or others
									{
										aesl_tmp_3[i_0].user = (_dst_V_user_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str();
										hls_map_index++;
									}
								}
							}
						}
					}
				}
			}
		}

		// output port post check: "p_dst_V_last_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_last_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_last_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_last_V, AESL_token); // data

			std::vector<sc_bv<1> > p_dst_V_last_V_pc_buffer;
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_last_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_last_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					p_dst_V_last_V_pc_buffer.push_back(AESL_token.c_str());
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_last_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_p_dst_V_last_V))
				{
					exit(1);
				}
			}

			// correct the buffer size the current transaction
			if (i != aesl_tmp_4)
			{
				aesl_tmp_4 = i;
			}

			if (aesl_tmp_4 > 0 && aesl_tmp_3.size() < aesl_tmp_4)
			{
				int aesl_tmp_3_size = aesl_tmp_3.size();

				for (int tmp_aesl_tmp_3 = 0; tmp_aesl_tmp_3 < aesl_tmp_4 - aesl_tmp_3_size; tmp_aesl_tmp_3++)
				{
					ap_axiu<24, 1, 1, 1 > tmp;
					aesl_tmp_3.push_back(tmp);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: p_dst_V_last_V
				{
					// bitslice(0, 0)
					// {
						// celement: _dst.V.last.V(0, 0)
						// {
							sc_lv<1>* _dst_V_last_V_lv0_0_0_1_lv1_0_0_1 = new sc_lv<1>[aesl_tmp_4 - aesl_tmp_5];
						// }
					// }

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.last.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									if (&(aesl_tmp_3[0].last) != NULL) // check the null address if the c port is array or others
									{
										_dst_V_last_V_lv0_0_0_1_lv1_0_0_1[hls_map_index].range(0, 0) = sc_bv<1>(p_dst_V_last_V_pc_buffer[hls_map_index].range(0, 0));
										hls_map_index++;
									}
								}
							}
						}
					}

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.last.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									// sub                    : i_0 i_1
									// ori_name               : aesl_tmp_3[i_0].last
									// sub_1st_elem           : 0 0
									// ori_name_1st_elem      : aesl_tmp_3[0].last
									// output_left_conversion : aesl_tmp_3[i_0].last
									// output_type_conversion : (_dst_V_last_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str()
									if (&(aesl_tmp_3[0].last) != NULL) // check the null address if the c port is array or others
									{
										aesl_tmp_3[i_0].last = (_dst_V_last_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str();
										hls_map_index++;
									}
								}
							}
						}
					}
				}
			}
		}

		// output port post check: "p_dst_V_id_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_id_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_id_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_id_V, AESL_token); // data

			std::vector<sc_bv<1> > p_dst_V_id_V_pc_buffer;
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_id_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_id_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					p_dst_V_id_V_pc_buffer.push_back(AESL_token.c_str());
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_id_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_p_dst_V_id_V))
				{
					exit(1);
				}
			}

			// correct the buffer size the current transaction
			if (i != aesl_tmp_4)
			{
				aesl_tmp_4 = i;
			}

			if (aesl_tmp_4 > 0 && aesl_tmp_3.size() < aesl_tmp_4)
			{
				int aesl_tmp_3_size = aesl_tmp_3.size();

				for (int tmp_aesl_tmp_3 = 0; tmp_aesl_tmp_3 < aesl_tmp_4 - aesl_tmp_3_size; tmp_aesl_tmp_3++)
				{
					ap_axiu<24, 1, 1, 1 > tmp;
					aesl_tmp_3.push_back(tmp);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: p_dst_V_id_V
				{
					// bitslice(0, 0)
					// {
						// celement: _dst.V.id.V(0, 0)
						// {
							sc_lv<1>* _dst_V_id_V_lv0_0_0_1_lv1_0_0_1 = new sc_lv<1>[aesl_tmp_4 - aesl_tmp_5];
						// }
					// }

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.id.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									if (&(aesl_tmp_3[0].id) != NULL) // check the null address if the c port is array or others
									{
										_dst_V_id_V_lv0_0_0_1_lv1_0_0_1[hls_map_index].range(0, 0) = sc_bv<1>(p_dst_V_id_V_pc_buffer[hls_map_index].range(0, 0));
										hls_map_index++;
									}
								}
							}
						}
					}

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.id.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									// sub                    : i_0 i_1
									// ori_name               : aesl_tmp_3[i_0].id
									// sub_1st_elem           : 0 0
									// ori_name_1st_elem      : aesl_tmp_3[0].id
									// output_left_conversion : aesl_tmp_3[i_0].id
									// output_type_conversion : (_dst_V_id_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str()
									if (&(aesl_tmp_3[0].id) != NULL) // check the null address if the c port is array or others
									{
										aesl_tmp_3[i_0].id = (_dst_V_id_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str();
										hls_map_index++;
									}
								}
							}
						}
					}
				}
			}
		}

		// output port post check: "p_dst_V_dest_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_dest_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_dest_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_dest_V, AESL_token); // data

			std::vector<sc_bv<1> > p_dst_V_dest_V_pc_buffer;
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_dest_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'p_dst_V_dest_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					p_dst_V_dest_V_pc_buffer.push_back(AESL_token.c_str());
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_p_dst_V_dest_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_p_dst_V_dest_V))
				{
					exit(1);
				}
			}

			// correct the buffer size the current transaction
			if (i != aesl_tmp_4)
			{
				aesl_tmp_4 = i;
			}

			if (aesl_tmp_4 > 0 && aesl_tmp_3.size() < aesl_tmp_4)
			{
				int aesl_tmp_3_size = aesl_tmp_3.size();

				for (int tmp_aesl_tmp_3 = 0; tmp_aesl_tmp_3 < aesl_tmp_4 - aesl_tmp_3_size; tmp_aesl_tmp_3++)
				{
					ap_axiu<24, 1, 1, 1 > tmp;
					aesl_tmp_3.push_back(tmp);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: p_dst_V_dest_V
				{
					// bitslice(0, 0)
					// {
						// celement: _dst.V.dest.V(0, 0)
						// {
							sc_lv<1>* _dst_V_dest_V_lv0_0_0_1_lv1_0_0_1 = new sc_lv<1>[aesl_tmp_4 - aesl_tmp_5];
						// }
					// }

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.dest.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									if (&(aesl_tmp_3[0].dest) != NULL) // check the null address if the c port is array or others
									{
										_dst_V_dest_V_lv0_0_0_1_lv1_0_0_1[hls_map_index].range(0, 0) = sc_bv<1>(p_dst_V_dest_V_pc_buffer[hls_map_index].range(0, 0));
										hls_map_index++;
									}
								}
							}
						}
					}

					// bitslice(0, 0)
					{
						int hls_map_index = 0;
						// celement: _dst.V.dest.V(0, 0)
						{
							// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
							for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
							{
								// carray: (0) => (0) @ (1)
								for (int i_1 = 0; i_1 <= 0; i_1 += 1)
								{
									// sub                    : i_0 i_1
									// ori_name               : aesl_tmp_3[i_0].dest
									// sub_1st_elem           : 0 0
									// ori_name_1st_elem      : aesl_tmp_3[0].dest
									// output_left_conversion : aesl_tmp_3[i_0].dest
									// output_type_conversion : (_dst_V_dest_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str()
									if (&(aesl_tmp_3[0].dest) != NULL) // check the null address if the c port is array or others
									{
										aesl_tmp_3[i_0].dest = (_dst_V_dest_V_lv0_0_0_1_lv1_0_0_1[hls_map_index]).to_string(SC_BIN).c_str();
										hls_map_index++;
									}
								}
							}
						}
					}
				}
			}
		}

		// push back output stream: "_dst"
		for (int i = 0; i < aesl_tmp_4; i++)
		{
			_dst.write(aesl_tmp_3[i]);
		}

		AESL_transaction_pc++;
	}
	else
	{
		CodeState = ENTER_WRAPC;
		static unsigned AESL_transaction;

		static AESL_FILE_HANDLER aesl_fh;

		// "p_src_V_data_V"
		char* tvin_p_src_V_data_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_src_V_data_V);
		char* wrapc_stream_size_in_p_src_V_data_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_IN_p_src_V_data_V);
		char* wrapc_stream_ingress_status_p_src_V_data_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V);

		// "p_src_V_keep_V"
		char* tvin_p_src_V_keep_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_src_V_keep_V);
		char* wrapc_stream_size_in_p_src_V_keep_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_IN_p_src_V_keep_V);
		char* wrapc_stream_ingress_status_p_src_V_keep_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V);

		// "p_src_V_strb_V"
		char* tvin_p_src_V_strb_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_src_V_strb_V);
		char* wrapc_stream_size_in_p_src_V_strb_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_IN_p_src_V_strb_V);
		char* wrapc_stream_ingress_status_p_src_V_strb_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V);

		// "p_src_V_user_V"
		char* tvin_p_src_V_user_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_src_V_user_V);
		char* wrapc_stream_size_in_p_src_V_user_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_IN_p_src_V_user_V);
		char* wrapc_stream_ingress_status_p_src_V_user_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V);

		// "p_src_V_last_V"
		char* tvin_p_src_V_last_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_src_V_last_V);
		char* wrapc_stream_size_in_p_src_V_last_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_IN_p_src_V_last_V);
		char* wrapc_stream_ingress_status_p_src_V_last_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V);

		// "p_src_V_id_V"
		char* tvin_p_src_V_id_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_src_V_id_V);
		char* wrapc_stream_size_in_p_src_V_id_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_IN_p_src_V_id_V);
		char* wrapc_stream_ingress_status_p_src_V_id_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V);

		// "p_src_V_dest_V"
		char* tvin_p_src_V_dest_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_src_V_dest_V);
		char* wrapc_stream_size_in_p_src_V_dest_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_IN_p_src_V_dest_V);
		char* wrapc_stream_ingress_status_p_src_V_dest_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V);

		// "p_dst_V_data_V"
		char* tvin_p_dst_V_data_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_dst_V_data_V);
		char* tvout_p_dst_V_data_V = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_p_dst_V_data_V);
		char* wrapc_stream_size_out_p_dst_V_data_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V);
		char* wrapc_stream_egress_status_p_dst_V_data_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_EGRESS_STATUS_p_dst_V_data_V);

		// "p_dst_V_keep_V"
		char* tvin_p_dst_V_keep_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_dst_V_keep_V);
		char* tvout_p_dst_V_keep_V = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_p_dst_V_keep_V);
		char* wrapc_stream_size_out_p_dst_V_keep_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_OUT_p_dst_V_keep_V);
		char* wrapc_stream_egress_status_p_dst_V_keep_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_EGRESS_STATUS_p_dst_V_keep_V);

		// "p_dst_V_strb_V"
		char* tvin_p_dst_V_strb_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_dst_V_strb_V);
		char* tvout_p_dst_V_strb_V = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_p_dst_V_strb_V);
		char* wrapc_stream_size_out_p_dst_V_strb_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_OUT_p_dst_V_strb_V);
		char* wrapc_stream_egress_status_p_dst_V_strb_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_EGRESS_STATUS_p_dst_V_strb_V);

		// "p_dst_V_user_V"
		char* tvin_p_dst_V_user_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_dst_V_user_V);
		char* tvout_p_dst_V_user_V = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_p_dst_V_user_V);
		char* wrapc_stream_size_out_p_dst_V_user_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_OUT_p_dst_V_user_V);
		char* wrapc_stream_egress_status_p_dst_V_user_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_EGRESS_STATUS_p_dst_V_user_V);

		// "p_dst_V_last_V"
		char* tvin_p_dst_V_last_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_dst_V_last_V);
		char* tvout_p_dst_V_last_V = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_p_dst_V_last_V);
		char* wrapc_stream_size_out_p_dst_V_last_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_OUT_p_dst_V_last_V);
		char* wrapc_stream_egress_status_p_dst_V_last_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_EGRESS_STATUS_p_dst_V_last_V);

		// "p_dst_V_id_V"
		char* tvin_p_dst_V_id_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_dst_V_id_V);
		char* tvout_p_dst_V_id_V = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_p_dst_V_id_V);
		char* wrapc_stream_size_out_p_dst_V_id_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_OUT_p_dst_V_id_V);
		char* wrapc_stream_egress_status_p_dst_V_id_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_EGRESS_STATUS_p_dst_V_id_V);

		// "p_dst_V_dest_V"
		char* tvin_p_dst_V_dest_V = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_p_dst_V_dest_V);
		char* tvout_p_dst_V_dest_V = new char[50];
		aesl_fh.touch(AUTOTB_TVOUT_p_dst_V_dest_V);
		char* wrapc_stream_size_out_p_dst_V_dest_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_SIZE_OUT_p_dst_V_dest_V);
		char* wrapc_stream_egress_status_p_dst_V_dest_V = new char[50];
		aesl_fh.touch(WRAPC_STREAM_EGRESS_STATUS_p_dst_V_dest_V);

		// "src_height"
		char* tvin_src_height = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_src_height);

		// "src_width"
		char* tvin_src_width = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_src_width);

		// "dst_height"
		char* tvin_dst_height = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_dst_height);

		// "dst_width"
		char* tvin_dst_width = new char[50];
		aesl_fh.touch(AUTOTB_TVIN_dst_width);

		CodeState = DUMP_INPUTS;
		static INTER_TCL_FILE tcl_file(INTER_TCL);
		int leading_zero;

		// dump stream tvin: "_src"
		std::vector<ap_axiu<24, 1, 1, 1 > > aesl_tmp_0;
		int aesl_tmp_1 = 0;
		while (!_src.empty())
		{
			aesl_tmp_0.push_back(_src.read());
			aesl_tmp_1++;
		}

		// dump stream tvin: "_dst"
		std::vector<ap_axiu<24, 1, 1, 1 > > aesl_tmp_3;
		int aesl_tmp_4 = 0;
		while (!_dst.empty())
		{
			aesl_tmp_3.push_back(_dst.read());
			aesl_tmp_4++;
		}

		// [[transaction]]
		sprintf(tvin_src_height, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_src_height, tvin_src_height);

		sc_bv<32> src_height_tvin_wrapc_buffer;

		// RTL Name: src_height
		{
			// bitslice(31, 0)
			{
				// celement: src_height(31, 0)
				{
					// carray: (0) => (0) @ (0)
					{
						// sub                   : 
						// ori_name              : src_height
						// sub_1st_elem          : 
						// ori_name_1st_elem     : src_height
						// regulate_c_name       : src_height
						// input_type_conversion : src_height
						if (&(src_height) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> src_height_tmp_mem;
							src_height_tmp_mem = src_height;
							src_height_tvin_wrapc_buffer.range(31, 0) = src_height_tmp_mem.range(31, 0);
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_src_height, "%s\n", (src_height_tvin_wrapc_buffer).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_src_height, tvin_src_height);
		}

		tcl_file.set_num(1, &tcl_file.src_height_depth);
		sprintf(tvin_src_height, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_src_height, tvin_src_height);

		// [[transaction]]
		sprintf(tvin_src_width, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_src_width, tvin_src_width);

		sc_bv<32> src_width_tvin_wrapc_buffer;

		// RTL Name: src_width
		{
			// bitslice(31, 0)
			{
				// celement: src_width(31, 0)
				{
					// carray: (0) => (0) @ (0)
					{
						// sub                   : 
						// ori_name              : src_width
						// sub_1st_elem          : 
						// ori_name_1st_elem     : src_width
						// regulate_c_name       : src_width
						// input_type_conversion : src_width
						if (&(src_width) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> src_width_tmp_mem;
							src_width_tmp_mem = src_width;
							src_width_tvin_wrapc_buffer.range(31, 0) = src_width_tmp_mem.range(31, 0);
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_src_width, "%s\n", (src_width_tvin_wrapc_buffer).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_src_width, tvin_src_width);
		}

		tcl_file.set_num(1, &tcl_file.src_width_depth);
		sprintf(tvin_src_width, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_src_width, tvin_src_width);

		// [[transaction]]
		sprintf(tvin_dst_height, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_dst_height, tvin_dst_height);

		sc_bv<32> dst_height_tvin_wrapc_buffer;

		// RTL Name: dst_height
		{
			// bitslice(31, 0)
			{
				// celement: dst_height(31, 0)
				{
					// carray: (0) => (0) @ (0)
					{
						// sub                   : 
						// ori_name              : dst_height
						// sub_1st_elem          : 
						// ori_name_1st_elem     : dst_height
						// regulate_c_name       : dst_height
						// input_type_conversion : dst_height
						if (&(dst_height) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> dst_height_tmp_mem;
							dst_height_tmp_mem = dst_height;
							dst_height_tvin_wrapc_buffer.range(31, 0) = dst_height_tmp_mem.range(31, 0);
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_dst_height, "%s\n", (dst_height_tvin_wrapc_buffer).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_dst_height, tvin_dst_height);
		}

		tcl_file.set_num(1, &tcl_file.dst_height_depth);
		sprintf(tvin_dst_height, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_dst_height, tvin_dst_height);

		// [[transaction]]
		sprintf(tvin_dst_width, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_dst_width, tvin_dst_width);

		sc_bv<32> dst_width_tvin_wrapc_buffer;

		// RTL Name: dst_width
		{
			// bitslice(31, 0)
			{
				// celement: dst_width(31, 0)
				{
					// carray: (0) => (0) @ (0)
					{
						// sub                   : 
						// ori_name              : dst_width
						// sub_1st_elem          : 
						// ori_name_1st_elem     : dst_width
						// regulate_c_name       : dst_width
						// input_type_conversion : dst_width
						if (&(dst_width) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<32> dst_width_tmp_mem;
							dst_width_tmp_mem = dst_width;
							dst_width_tvin_wrapc_buffer.range(31, 0) = dst_width_tmp_mem.range(31, 0);
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_dst_width, "%s\n", (dst_width_tvin_wrapc_buffer).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_dst_width, tvin_dst_width);
		}

		tcl_file.set_num(1, &tcl_file.dst_width_depth);
		sprintf(tvin_dst_width, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_dst_width, tvin_dst_width);

		// push back input stream: "_src"
		for (int i = 0; i < aesl_tmp_1; i++)
		{
			_src.write(aesl_tmp_0[i]);
		}

		// push back input stream: "_dst"
		for (int i = 0; i < aesl_tmp_4; i++)
		{
			_dst.write(aesl_tmp_3[i]);
		}

// [call_c_dut] ---------->

		CodeState = CALL_C_DUT;
		ip_accel_app(_src, _dst, src_height, src_width, dst_height, dst_width);

		CodeState = DUMP_OUTPUTS;
		// record input size to tv3: "_src"
		int aesl_tmp_2 = _src.size();

		// pop output stream: "_dst"
		int aesl_tmp_5 = aesl_tmp_4;
		aesl_tmp_4 = 0;
     aesl_tmp_3.clear();
		while (!_dst.empty())
		{
			aesl_tmp_3.push_back(_dst.read());
			aesl_tmp_4++;
		}

		// [[transaction]]
		sprintf(tvin_p_src_V_data_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_p_src_V_data_V, tvin_p_src_V_data_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, tvin_p_src_V_data_V);

		sc_bv<24>* p_src_V_data_V_tvin_wrapc_buffer = new sc_bv<24>[aesl_tmp_1 - aesl_tmp_2];

		// RTL Name: p_src_V_data_V
		{
			// bitslice(23, 0)
			{
				int hls_map_index = 0;
				// celement: _src.V.data.V(23, 0)
				{
					// carray: (0) => (aesl_tmp_1 - aesl_tmp_2 - 1) @ (1)
					for (int i_0 = 0; i_0 <= aesl_tmp_1 - aesl_tmp_2 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_0[i_0].data
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_0[0].data
							// regulate_c_name       : _src_V_data_V
							// input_type_conversion : (aesl_tmp_0[i_0].data).to_string(2).c_str()
							if (&(aesl_tmp_0[0].data) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<24> _src_V_data_V_tmp_mem;
								_src_V_data_V_tmp_mem = (aesl_tmp_0[i_0].data).to_string(2).c_str();
								p_src_V_data_V_tvin_wrapc_buffer[hls_map_index].range(23, 0) = _src_V_data_V_tmp_mem.range(23, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			sprintf(tvin_p_src_V_data_V, "%s\n", (p_src_V_data_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_p_src_V_data_V, tvin_p_src_V_data_V);
		}

		// dump stream ingress status to file
     if (aesl_tmp_1 > aesl_tmp_2)
     {
		sc_int<32> stream_ingress_size_p_src_V_data_V = aesl_tmp_1;
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, stream_ingress_size_p_src_V_data_V.to_string().c_str());
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, "\n");

		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			stream_ingress_size_p_src_V_data_V--;
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, stream_ingress_size_p_src_V_data_V.to_string().c_str());
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, "\n");
		}
     }
     else {
		    sc_int<32> stream_ingress_size_p_src_V_data_V = 0;
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, stream_ingress_size_p_src_V_data_V.to_string().c_str());
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, "\n");
     }

		tcl_file.set_num(aesl_tmp_1 - aesl_tmp_2, &tcl_file.p_src_V_data_V_depth);
		sprintf(tvin_p_src_V_data_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_p_src_V_data_V, tvin_p_src_V_data_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_data_V, tvin_p_src_V_data_V);

		// release memory allocation
		delete [] p_src_V_data_V_tvin_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_in_p_src_V_data_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_data_V, wrapc_stream_size_in_p_src_V_data_V);
		sprintf(wrapc_stream_size_in_p_src_V_data_V, "%d\n", aesl_tmp_1 - aesl_tmp_2);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_data_V, wrapc_stream_size_in_p_src_V_data_V);
		sprintf(wrapc_stream_size_in_p_src_V_data_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_data_V, wrapc_stream_size_in_p_src_V_data_V);

		// [[transaction]]
		sprintf(tvin_p_src_V_keep_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_p_src_V_keep_V, tvin_p_src_V_keep_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, tvin_p_src_V_keep_V);

		sc_bv<3>* p_src_V_keep_V_tvin_wrapc_buffer = new sc_bv<3>[aesl_tmp_1 - aesl_tmp_2];

		// RTL Name: p_src_V_keep_V
		{
			// bitslice(2, 0)
			{
				int hls_map_index = 0;
				// celement: _src.V.keep.V(2, 0)
				{
					// carray: (0) => (aesl_tmp_1 - aesl_tmp_2 - 1) @ (1)
					for (int i_0 = 0; i_0 <= aesl_tmp_1 - aesl_tmp_2 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_0[i_0].keep
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_0[0].keep
							// regulate_c_name       : _src_V_keep_V
							// input_type_conversion : (aesl_tmp_0[i_0].keep).to_string(2).c_str()
							if (&(aesl_tmp_0[0].keep) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<3> _src_V_keep_V_tmp_mem;
								_src_V_keep_V_tmp_mem = (aesl_tmp_0[i_0].keep).to_string(2).c_str();
								p_src_V_keep_V_tvin_wrapc_buffer[hls_map_index].range(2, 0) = _src_V_keep_V_tmp_mem.range(2, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			sprintf(tvin_p_src_V_keep_V, "%s\n", (p_src_V_keep_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_p_src_V_keep_V, tvin_p_src_V_keep_V);
		}

		// dump stream ingress status to file
     if (aesl_tmp_1 > aesl_tmp_2)
     {
		sc_int<32> stream_ingress_size_p_src_V_keep_V = aesl_tmp_1;
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, stream_ingress_size_p_src_V_keep_V.to_string().c_str());
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, "\n");

		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			stream_ingress_size_p_src_V_keep_V--;
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, stream_ingress_size_p_src_V_keep_V.to_string().c_str());
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, "\n");
		}
     }
     else {
		    sc_int<32> stream_ingress_size_p_src_V_keep_V = 0;
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, stream_ingress_size_p_src_V_keep_V.to_string().c_str());
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, "\n");
     }

		tcl_file.set_num(aesl_tmp_1 - aesl_tmp_2, &tcl_file.p_src_V_keep_V_depth);
		sprintf(tvin_p_src_V_keep_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_p_src_V_keep_V, tvin_p_src_V_keep_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_keep_V, tvin_p_src_V_keep_V);

		// release memory allocation
		delete [] p_src_V_keep_V_tvin_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_in_p_src_V_keep_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_keep_V, wrapc_stream_size_in_p_src_V_keep_V);
		sprintf(wrapc_stream_size_in_p_src_V_keep_V, "%d\n", aesl_tmp_1 - aesl_tmp_2);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_keep_V, wrapc_stream_size_in_p_src_V_keep_V);
		sprintf(wrapc_stream_size_in_p_src_V_keep_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_keep_V, wrapc_stream_size_in_p_src_V_keep_V);

		// [[transaction]]
		sprintf(tvin_p_src_V_strb_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_p_src_V_strb_V, tvin_p_src_V_strb_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, tvin_p_src_V_strb_V);

		sc_bv<3>* p_src_V_strb_V_tvin_wrapc_buffer = new sc_bv<3>[aesl_tmp_1 - aesl_tmp_2];

		// RTL Name: p_src_V_strb_V
		{
			// bitslice(2, 0)
			{
				int hls_map_index = 0;
				// celement: _src.V.strb.V(2, 0)
				{
					// carray: (0) => (aesl_tmp_1 - aesl_tmp_2 - 1) @ (1)
					for (int i_0 = 0; i_0 <= aesl_tmp_1 - aesl_tmp_2 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_0[i_0].strb
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_0[0].strb
							// regulate_c_name       : _src_V_strb_V
							// input_type_conversion : (aesl_tmp_0[i_0].strb).to_string(2).c_str()
							if (&(aesl_tmp_0[0].strb) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<3> _src_V_strb_V_tmp_mem;
								_src_V_strb_V_tmp_mem = (aesl_tmp_0[i_0].strb).to_string(2).c_str();
								p_src_V_strb_V_tvin_wrapc_buffer[hls_map_index].range(2, 0) = _src_V_strb_V_tmp_mem.range(2, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			sprintf(tvin_p_src_V_strb_V, "%s\n", (p_src_V_strb_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_p_src_V_strb_V, tvin_p_src_V_strb_V);
		}

		// dump stream ingress status to file
     if (aesl_tmp_1 > aesl_tmp_2)
     {
		sc_int<32> stream_ingress_size_p_src_V_strb_V = aesl_tmp_1;
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, stream_ingress_size_p_src_V_strb_V.to_string().c_str());
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, "\n");

		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			stream_ingress_size_p_src_V_strb_V--;
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, stream_ingress_size_p_src_V_strb_V.to_string().c_str());
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, "\n");
		}
     }
     else {
		    sc_int<32> stream_ingress_size_p_src_V_strb_V = 0;
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, stream_ingress_size_p_src_V_strb_V.to_string().c_str());
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, "\n");
     }

		tcl_file.set_num(aesl_tmp_1 - aesl_tmp_2, &tcl_file.p_src_V_strb_V_depth);
		sprintf(tvin_p_src_V_strb_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_p_src_V_strb_V, tvin_p_src_V_strb_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_strb_V, tvin_p_src_V_strb_V);

		// release memory allocation
		delete [] p_src_V_strb_V_tvin_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_in_p_src_V_strb_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_strb_V, wrapc_stream_size_in_p_src_V_strb_V);
		sprintf(wrapc_stream_size_in_p_src_V_strb_V, "%d\n", aesl_tmp_1 - aesl_tmp_2);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_strb_V, wrapc_stream_size_in_p_src_V_strb_V);
		sprintf(wrapc_stream_size_in_p_src_V_strb_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_strb_V, wrapc_stream_size_in_p_src_V_strb_V);

		// [[transaction]]
		sprintf(tvin_p_src_V_user_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_p_src_V_user_V, tvin_p_src_V_user_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, tvin_p_src_V_user_V);

		sc_bv<1>* p_src_V_user_V_tvin_wrapc_buffer = new sc_bv<1>[aesl_tmp_1 - aesl_tmp_2];

		// RTL Name: p_src_V_user_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _src.V.user.V(0, 0)
				{
					// carray: (0) => (aesl_tmp_1 - aesl_tmp_2 - 1) @ (1)
					for (int i_0 = 0; i_0 <= aesl_tmp_1 - aesl_tmp_2 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_0[i_0].user
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_0[0].user
							// regulate_c_name       : _src_V_user_V
							// input_type_conversion : (aesl_tmp_0[i_0].user).to_string(2).c_str()
							if (&(aesl_tmp_0[0].user) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _src_V_user_V_tmp_mem;
								_src_V_user_V_tmp_mem = (aesl_tmp_0[i_0].user).to_string(2).c_str();
								p_src_V_user_V_tvin_wrapc_buffer[hls_map_index].range(0, 0) = _src_V_user_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			sprintf(tvin_p_src_V_user_V, "%s\n", (p_src_V_user_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_p_src_V_user_V, tvin_p_src_V_user_V);
		}

		// dump stream ingress status to file
     if (aesl_tmp_1 > aesl_tmp_2)
     {
		sc_int<32> stream_ingress_size_p_src_V_user_V = aesl_tmp_1;
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, stream_ingress_size_p_src_V_user_V.to_string().c_str());
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, "\n");

		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			stream_ingress_size_p_src_V_user_V--;
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, stream_ingress_size_p_src_V_user_V.to_string().c_str());
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, "\n");
		}
     }
     else {
		    sc_int<32> stream_ingress_size_p_src_V_user_V = 0;
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, stream_ingress_size_p_src_V_user_V.to_string().c_str());
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, "\n");
     }

		tcl_file.set_num(aesl_tmp_1 - aesl_tmp_2, &tcl_file.p_src_V_user_V_depth);
		sprintf(tvin_p_src_V_user_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_p_src_V_user_V, tvin_p_src_V_user_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_user_V, tvin_p_src_V_user_V);

		// release memory allocation
		delete [] p_src_V_user_V_tvin_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_in_p_src_V_user_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_user_V, wrapc_stream_size_in_p_src_V_user_V);
		sprintf(wrapc_stream_size_in_p_src_V_user_V, "%d\n", aesl_tmp_1 - aesl_tmp_2);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_user_V, wrapc_stream_size_in_p_src_V_user_V);
		sprintf(wrapc_stream_size_in_p_src_V_user_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_user_V, wrapc_stream_size_in_p_src_V_user_V);

		// [[transaction]]
		sprintf(tvin_p_src_V_last_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_p_src_V_last_V, tvin_p_src_V_last_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, tvin_p_src_V_last_V);

		sc_bv<1>* p_src_V_last_V_tvin_wrapc_buffer = new sc_bv<1>[aesl_tmp_1 - aesl_tmp_2];

		// RTL Name: p_src_V_last_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _src.V.last.V(0, 0)
				{
					// carray: (0) => (aesl_tmp_1 - aesl_tmp_2 - 1) @ (1)
					for (int i_0 = 0; i_0 <= aesl_tmp_1 - aesl_tmp_2 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_0[i_0].last
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_0[0].last
							// regulate_c_name       : _src_V_last_V
							// input_type_conversion : (aesl_tmp_0[i_0].last).to_string(2).c_str()
							if (&(aesl_tmp_0[0].last) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _src_V_last_V_tmp_mem;
								_src_V_last_V_tmp_mem = (aesl_tmp_0[i_0].last).to_string(2).c_str();
								p_src_V_last_V_tvin_wrapc_buffer[hls_map_index].range(0, 0) = _src_V_last_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			sprintf(tvin_p_src_V_last_V, "%s\n", (p_src_V_last_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_p_src_V_last_V, tvin_p_src_V_last_V);
		}

		// dump stream ingress status to file
     if (aesl_tmp_1 > aesl_tmp_2)
     {
		sc_int<32> stream_ingress_size_p_src_V_last_V = aesl_tmp_1;
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, stream_ingress_size_p_src_V_last_V.to_string().c_str());
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, "\n");

		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			stream_ingress_size_p_src_V_last_V--;
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, stream_ingress_size_p_src_V_last_V.to_string().c_str());
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, "\n");
		}
     }
     else {
		    sc_int<32> stream_ingress_size_p_src_V_last_V = 0;
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, stream_ingress_size_p_src_V_last_V.to_string().c_str());
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, "\n");
     }

		tcl_file.set_num(aesl_tmp_1 - aesl_tmp_2, &tcl_file.p_src_V_last_V_depth);
		sprintf(tvin_p_src_V_last_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_p_src_V_last_V, tvin_p_src_V_last_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_last_V, tvin_p_src_V_last_V);

		// release memory allocation
		delete [] p_src_V_last_V_tvin_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_in_p_src_V_last_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_last_V, wrapc_stream_size_in_p_src_V_last_V);
		sprintf(wrapc_stream_size_in_p_src_V_last_V, "%d\n", aesl_tmp_1 - aesl_tmp_2);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_last_V, wrapc_stream_size_in_p_src_V_last_V);
		sprintf(wrapc_stream_size_in_p_src_V_last_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_last_V, wrapc_stream_size_in_p_src_V_last_V);

		// [[transaction]]
		sprintf(tvin_p_src_V_id_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_p_src_V_id_V, tvin_p_src_V_id_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, tvin_p_src_V_id_V);

		sc_bv<1>* p_src_V_id_V_tvin_wrapc_buffer = new sc_bv<1>[aesl_tmp_1 - aesl_tmp_2];

		// RTL Name: p_src_V_id_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _src.V.id.V(0, 0)
				{
					// carray: (0) => (aesl_tmp_1 - aesl_tmp_2 - 1) @ (1)
					for (int i_0 = 0; i_0 <= aesl_tmp_1 - aesl_tmp_2 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_0[i_0].id
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_0[0].id
							// regulate_c_name       : _src_V_id_V
							// input_type_conversion : (aesl_tmp_0[i_0].id).to_string(2).c_str()
							if (&(aesl_tmp_0[0].id) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _src_V_id_V_tmp_mem;
								_src_V_id_V_tmp_mem = (aesl_tmp_0[i_0].id).to_string(2).c_str();
								p_src_V_id_V_tvin_wrapc_buffer[hls_map_index].range(0, 0) = _src_V_id_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			sprintf(tvin_p_src_V_id_V, "%s\n", (p_src_V_id_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_p_src_V_id_V, tvin_p_src_V_id_V);
		}

		// dump stream ingress status to file
     if (aesl_tmp_1 > aesl_tmp_2)
     {
		sc_int<32> stream_ingress_size_p_src_V_id_V = aesl_tmp_1;
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, stream_ingress_size_p_src_V_id_V.to_string().c_str());
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, "\n");

		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			stream_ingress_size_p_src_V_id_V--;
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, stream_ingress_size_p_src_V_id_V.to_string().c_str());
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, "\n");
		}
     }
     else {
		    sc_int<32> stream_ingress_size_p_src_V_id_V = 0;
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, stream_ingress_size_p_src_V_id_V.to_string().c_str());
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, "\n");
     }

		tcl_file.set_num(aesl_tmp_1 - aesl_tmp_2, &tcl_file.p_src_V_id_V_depth);
		sprintf(tvin_p_src_V_id_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_p_src_V_id_V, tvin_p_src_V_id_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_id_V, tvin_p_src_V_id_V);

		// release memory allocation
		delete [] p_src_V_id_V_tvin_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_in_p_src_V_id_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_id_V, wrapc_stream_size_in_p_src_V_id_V);
		sprintf(wrapc_stream_size_in_p_src_V_id_V, "%d\n", aesl_tmp_1 - aesl_tmp_2);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_id_V, wrapc_stream_size_in_p_src_V_id_V);
		sprintf(wrapc_stream_size_in_p_src_V_id_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_id_V, wrapc_stream_size_in_p_src_V_id_V);

		// [[transaction]]
		sprintf(tvin_p_src_V_dest_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_p_src_V_dest_V, tvin_p_src_V_dest_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, tvin_p_src_V_dest_V);

		sc_bv<1>* p_src_V_dest_V_tvin_wrapc_buffer = new sc_bv<1>[aesl_tmp_1 - aesl_tmp_2];

		// RTL Name: p_src_V_dest_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _src.V.dest.V(0, 0)
				{
					// carray: (0) => (aesl_tmp_1 - aesl_tmp_2 - 1) @ (1)
					for (int i_0 = 0; i_0 <= aesl_tmp_1 - aesl_tmp_2 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_0[i_0].dest
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_0[0].dest
							// regulate_c_name       : _src_V_dest_V
							// input_type_conversion : (aesl_tmp_0[i_0].dest).to_string(2).c_str()
							if (&(aesl_tmp_0[0].dest) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _src_V_dest_V_tmp_mem;
								_src_V_dest_V_tmp_mem = (aesl_tmp_0[i_0].dest).to_string(2).c_str();
								p_src_V_dest_V_tvin_wrapc_buffer[hls_map_index].range(0, 0) = _src_V_dest_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			sprintf(tvin_p_src_V_dest_V, "%s\n", (p_src_V_dest_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_p_src_V_dest_V, tvin_p_src_V_dest_V);
		}

		// dump stream ingress status to file
     if (aesl_tmp_1 > aesl_tmp_2)
     {
		sc_int<32> stream_ingress_size_p_src_V_dest_V = aesl_tmp_1;
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, stream_ingress_size_p_src_V_dest_V.to_string().c_str());
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, "\n");

		for (int i = 0; i < aesl_tmp_1 - aesl_tmp_2; i++)
		{
			stream_ingress_size_p_src_V_dest_V--;
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, stream_ingress_size_p_src_V_dest_V.to_string().c_str());
			aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, "\n");
		}
     }
     else {
		    sc_int<32> stream_ingress_size_p_src_V_dest_V = 0;
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, stream_ingress_size_p_src_V_dest_V.to_string().c_str());
		    aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, "\n");
     }

		tcl_file.set_num(aesl_tmp_1 - aesl_tmp_2, &tcl_file.p_src_V_dest_V_depth);
		sprintf(tvin_p_src_V_dest_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_p_src_V_dest_V, tvin_p_src_V_dest_V);
		aesl_fh.write(WRAPC_STREAM_INGRESS_STATUS_p_src_V_dest_V, tvin_p_src_V_dest_V);

		// release memory allocation
		delete [] p_src_V_dest_V_tvin_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_in_p_src_V_dest_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_dest_V, wrapc_stream_size_in_p_src_V_dest_V);
		sprintf(wrapc_stream_size_in_p_src_V_dest_V, "%d\n", aesl_tmp_1 - aesl_tmp_2);
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_dest_V, wrapc_stream_size_in_p_src_V_dest_V);
		sprintf(wrapc_stream_size_in_p_src_V_dest_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_IN_p_src_V_dest_V, wrapc_stream_size_in_p_src_V_dest_V);

		// [[transaction]]
		sprintf(tvout_p_dst_V_data_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_data_V, tvout_p_dst_V_data_V);

		sc_bv<24>* p_dst_V_data_V_tvout_wrapc_buffer = new sc_bv<24>[aesl_tmp_4 - aesl_tmp_5];

		// RTL Name: p_dst_V_data_V
		{
			// bitslice(23, 0)
			{
				int hls_map_index = 0;
				// celement: _dst.V.data.V(23, 0)
				{
					// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
					for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_3[i_0].data
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_3[0].data
							// regulate_c_name       : _dst_V_data_V
							// input_type_conversion : (aesl_tmp_3[i_0].data).to_string(2).c_str()
							if (&(aesl_tmp_3[0].data) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<24> _dst_V_data_V_tmp_mem;
								_dst_V_data_V_tmp_mem = (aesl_tmp_3[i_0].data).to_string(2).c_str();
								p_dst_V_data_V_tvout_wrapc_buffer[hls_map_index].range(23, 0) = _dst_V_data_V_tmp_mem.range(23, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_4 - aesl_tmp_5; i++)
		{
			sprintf(tvout_p_dst_V_data_V, "%s\n", (p_dst_V_data_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_p_dst_V_data_V, tvout_p_dst_V_data_V);
		}

		tcl_file.set_num(aesl_tmp_4 - aesl_tmp_5, &tcl_file.p_dst_V_data_V_depth);
		sprintf(tvout_p_dst_V_data_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_data_V, tvout_p_dst_V_data_V);

		// release memory allocation
		delete [] p_dst_V_data_V_tvout_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_out_p_dst_V_data_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V, wrapc_stream_size_out_p_dst_V_data_V);
		sprintf(wrapc_stream_size_out_p_dst_V_data_V, "%d\n", aesl_tmp_4 - aesl_tmp_5);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V, wrapc_stream_size_out_p_dst_V_data_V);
		sprintf(wrapc_stream_size_out_p_dst_V_data_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_data_V, wrapc_stream_size_out_p_dst_V_data_V);

		// [[transaction]]
		sprintf(tvout_p_dst_V_keep_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_keep_V, tvout_p_dst_V_keep_V);

		sc_bv<3>* p_dst_V_keep_V_tvout_wrapc_buffer = new sc_bv<3>[aesl_tmp_4 - aesl_tmp_5];

		// RTL Name: p_dst_V_keep_V
		{
			// bitslice(2, 0)
			{
				int hls_map_index = 0;
				// celement: _dst.V.keep.V(2, 0)
				{
					// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
					for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_3[i_0].keep
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_3[0].keep
							// regulate_c_name       : _dst_V_keep_V
							// input_type_conversion : (aesl_tmp_3[i_0].keep).to_string(2).c_str()
							if (&(aesl_tmp_3[0].keep) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<3> _dst_V_keep_V_tmp_mem;
								_dst_V_keep_V_tmp_mem = (aesl_tmp_3[i_0].keep).to_string(2).c_str();
								p_dst_V_keep_V_tvout_wrapc_buffer[hls_map_index].range(2, 0) = _dst_V_keep_V_tmp_mem.range(2, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_4 - aesl_tmp_5; i++)
		{
			sprintf(tvout_p_dst_V_keep_V, "%s\n", (p_dst_V_keep_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_p_dst_V_keep_V, tvout_p_dst_V_keep_V);
		}

		tcl_file.set_num(aesl_tmp_4 - aesl_tmp_5, &tcl_file.p_dst_V_keep_V_depth);
		sprintf(tvout_p_dst_V_keep_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_keep_V, tvout_p_dst_V_keep_V);

		// release memory allocation
		delete [] p_dst_V_keep_V_tvout_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_out_p_dst_V_keep_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_keep_V, wrapc_stream_size_out_p_dst_V_keep_V);
		sprintf(wrapc_stream_size_out_p_dst_V_keep_V, "%d\n", aesl_tmp_4 - aesl_tmp_5);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_keep_V, wrapc_stream_size_out_p_dst_V_keep_V);
		sprintf(wrapc_stream_size_out_p_dst_V_keep_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_keep_V, wrapc_stream_size_out_p_dst_V_keep_V);

		// [[transaction]]
		sprintf(tvout_p_dst_V_strb_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_strb_V, tvout_p_dst_V_strb_V);

		sc_bv<3>* p_dst_V_strb_V_tvout_wrapc_buffer = new sc_bv<3>[aesl_tmp_4 - aesl_tmp_5];

		// RTL Name: p_dst_V_strb_V
		{
			// bitslice(2, 0)
			{
				int hls_map_index = 0;
				// celement: _dst.V.strb.V(2, 0)
				{
					// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
					for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_3[i_0].strb
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_3[0].strb
							// regulate_c_name       : _dst_V_strb_V
							// input_type_conversion : (aesl_tmp_3[i_0].strb).to_string(2).c_str()
							if (&(aesl_tmp_3[0].strb) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<3> _dst_V_strb_V_tmp_mem;
								_dst_V_strb_V_tmp_mem = (aesl_tmp_3[i_0].strb).to_string(2).c_str();
								p_dst_V_strb_V_tvout_wrapc_buffer[hls_map_index].range(2, 0) = _dst_V_strb_V_tmp_mem.range(2, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_4 - aesl_tmp_5; i++)
		{
			sprintf(tvout_p_dst_V_strb_V, "%s\n", (p_dst_V_strb_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_p_dst_V_strb_V, tvout_p_dst_V_strb_V);
		}

		tcl_file.set_num(aesl_tmp_4 - aesl_tmp_5, &tcl_file.p_dst_V_strb_V_depth);
		sprintf(tvout_p_dst_V_strb_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_strb_V, tvout_p_dst_V_strb_V);

		// release memory allocation
		delete [] p_dst_V_strb_V_tvout_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_out_p_dst_V_strb_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_strb_V, wrapc_stream_size_out_p_dst_V_strb_V);
		sprintf(wrapc_stream_size_out_p_dst_V_strb_V, "%d\n", aesl_tmp_4 - aesl_tmp_5);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_strb_V, wrapc_stream_size_out_p_dst_V_strb_V);
		sprintf(wrapc_stream_size_out_p_dst_V_strb_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_strb_V, wrapc_stream_size_out_p_dst_V_strb_V);

		// [[transaction]]
		sprintf(tvout_p_dst_V_user_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_user_V, tvout_p_dst_V_user_V);

		sc_bv<1>* p_dst_V_user_V_tvout_wrapc_buffer = new sc_bv<1>[aesl_tmp_4 - aesl_tmp_5];

		// RTL Name: p_dst_V_user_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _dst.V.user.V(0, 0)
				{
					// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
					for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_3[i_0].user
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_3[0].user
							// regulate_c_name       : _dst_V_user_V
							// input_type_conversion : (aesl_tmp_3[i_0].user).to_string(2).c_str()
							if (&(aesl_tmp_3[0].user) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _dst_V_user_V_tmp_mem;
								_dst_V_user_V_tmp_mem = (aesl_tmp_3[i_0].user).to_string(2).c_str();
								p_dst_V_user_V_tvout_wrapc_buffer[hls_map_index].range(0, 0) = _dst_V_user_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_4 - aesl_tmp_5; i++)
		{
			sprintf(tvout_p_dst_V_user_V, "%s\n", (p_dst_V_user_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_p_dst_V_user_V, tvout_p_dst_V_user_V);
		}

		tcl_file.set_num(aesl_tmp_4 - aesl_tmp_5, &tcl_file.p_dst_V_user_V_depth);
		sprintf(tvout_p_dst_V_user_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_user_V, tvout_p_dst_V_user_V);

		// release memory allocation
		delete [] p_dst_V_user_V_tvout_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_out_p_dst_V_user_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_user_V, wrapc_stream_size_out_p_dst_V_user_V);
		sprintf(wrapc_stream_size_out_p_dst_V_user_V, "%d\n", aesl_tmp_4 - aesl_tmp_5);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_user_V, wrapc_stream_size_out_p_dst_V_user_V);
		sprintf(wrapc_stream_size_out_p_dst_V_user_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_user_V, wrapc_stream_size_out_p_dst_V_user_V);

		// [[transaction]]
		sprintf(tvout_p_dst_V_last_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_last_V, tvout_p_dst_V_last_V);

		sc_bv<1>* p_dst_V_last_V_tvout_wrapc_buffer = new sc_bv<1>[aesl_tmp_4 - aesl_tmp_5];

		// RTL Name: p_dst_V_last_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _dst.V.last.V(0, 0)
				{
					// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
					for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_3[i_0].last
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_3[0].last
							// regulate_c_name       : _dst_V_last_V
							// input_type_conversion : (aesl_tmp_3[i_0].last).to_string(2).c_str()
							if (&(aesl_tmp_3[0].last) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _dst_V_last_V_tmp_mem;
								_dst_V_last_V_tmp_mem = (aesl_tmp_3[i_0].last).to_string(2).c_str();
								p_dst_V_last_V_tvout_wrapc_buffer[hls_map_index].range(0, 0) = _dst_V_last_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_4 - aesl_tmp_5; i++)
		{
			sprintf(tvout_p_dst_V_last_V, "%s\n", (p_dst_V_last_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_p_dst_V_last_V, tvout_p_dst_V_last_V);
		}

		tcl_file.set_num(aesl_tmp_4 - aesl_tmp_5, &tcl_file.p_dst_V_last_V_depth);
		sprintf(tvout_p_dst_V_last_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_last_V, tvout_p_dst_V_last_V);

		// release memory allocation
		delete [] p_dst_V_last_V_tvout_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_out_p_dst_V_last_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_last_V, wrapc_stream_size_out_p_dst_V_last_V);
		sprintf(wrapc_stream_size_out_p_dst_V_last_V, "%d\n", aesl_tmp_4 - aesl_tmp_5);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_last_V, wrapc_stream_size_out_p_dst_V_last_V);
		sprintf(wrapc_stream_size_out_p_dst_V_last_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_last_V, wrapc_stream_size_out_p_dst_V_last_V);

		// [[transaction]]
		sprintf(tvout_p_dst_V_id_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_id_V, tvout_p_dst_V_id_V);

		sc_bv<1>* p_dst_V_id_V_tvout_wrapc_buffer = new sc_bv<1>[aesl_tmp_4 - aesl_tmp_5];

		// RTL Name: p_dst_V_id_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _dst.V.id.V(0, 0)
				{
					// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
					for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_3[i_0].id
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_3[0].id
							// regulate_c_name       : _dst_V_id_V
							// input_type_conversion : (aesl_tmp_3[i_0].id).to_string(2).c_str()
							if (&(aesl_tmp_3[0].id) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _dst_V_id_V_tmp_mem;
								_dst_V_id_V_tmp_mem = (aesl_tmp_3[i_0].id).to_string(2).c_str();
								p_dst_V_id_V_tvout_wrapc_buffer[hls_map_index].range(0, 0) = _dst_V_id_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_4 - aesl_tmp_5; i++)
		{
			sprintf(tvout_p_dst_V_id_V, "%s\n", (p_dst_V_id_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_p_dst_V_id_V, tvout_p_dst_V_id_V);
		}

		tcl_file.set_num(aesl_tmp_4 - aesl_tmp_5, &tcl_file.p_dst_V_id_V_depth);
		sprintf(tvout_p_dst_V_id_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_id_V, tvout_p_dst_V_id_V);

		// release memory allocation
		delete [] p_dst_V_id_V_tvout_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_out_p_dst_V_id_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_id_V, wrapc_stream_size_out_p_dst_V_id_V);
		sprintf(wrapc_stream_size_out_p_dst_V_id_V, "%d\n", aesl_tmp_4 - aesl_tmp_5);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_id_V, wrapc_stream_size_out_p_dst_V_id_V);
		sprintf(wrapc_stream_size_out_p_dst_V_id_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_id_V, wrapc_stream_size_out_p_dst_V_id_V);

		// [[transaction]]
		sprintf(tvout_p_dst_V_dest_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_dest_V, tvout_p_dst_V_dest_V);

		sc_bv<1>* p_dst_V_dest_V_tvout_wrapc_buffer = new sc_bv<1>[aesl_tmp_4 - aesl_tmp_5];

		// RTL Name: p_dst_V_dest_V
		{
			// bitslice(0, 0)
			{
				int hls_map_index = 0;
				// celement: _dst.V.dest.V(0, 0)
				{
					// carray: (aesl_tmp_5) => (aesl_tmp_4 - 1) @ (1)
					for (int i_0 = aesl_tmp_5; i_0 <= aesl_tmp_4 - 1; i_0 += 1)
					{
						// carray: (0) => (0) @ (1)
						for (int i_1 = 0; i_1 <= 0; i_1 += 1)
						{
							// sub                   : i_0 i_1
							// ori_name              : aesl_tmp_3[i_0].dest
							// sub_1st_elem          : 0 0
							// ori_name_1st_elem     : aesl_tmp_3[0].dest
							// regulate_c_name       : _dst_V_dest_V
							// input_type_conversion : (aesl_tmp_3[i_0].dest).to_string(2).c_str()
							if (&(aesl_tmp_3[0].dest) != NULL) // check the null address if the c port is array or others
							{
								sc_lv<1> _dst_V_dest_V_tmp_mem;
								_dst_V_dest_V_tmp_mem = (aesl_tmp_3[i_0].dest).to_string(2).c_str();
								p_dst_V_dest_V_tvout_wrapc_buffer[hls_map_index].range(0, 0) = _dst_V_dest_V_tmp_mem.range(0, 0);
                                 		       hls_map_index++;
							}
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < aesl_tmp_4 - aesl_tmp_5; i++)
		{
			sprintf(tvout_p_dst_V_dest_V, "%s\n", (p_dst_V_dest_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_p_dst_V_dest_V, tvout_p_dst_V_dest_V);
		}

		tcl_file.set_num(aesl_tmp_4 - aesl_tmp_5, &tcl_file.p_dst_V_dest_V_depth);
		sprintf(tvout_p_dst_V_dest_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_p_dst_V_dest_V, tvout_p_dst_V_dest_V);

		// release memory allocation
		delete [] p_dst_V_dest_V_tvout_wrapc_buffer;

		// dump stream size
		sprintf(wrapc_stream_size_out_p_dst_V_dest_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_dest_V, wrapc_stream_size_out_p_dst_V_dest_V);
		sprintf(wrapc_stream_size_out_p_dst_V_dest_V, "%d\n", aesl_tmp_4 - aesl_tmp_5);
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_dest_V, wrapc_stream_size_out_p_dst_V_dest_V);
		sprintf(wrapc_stream_size_out_p_dst_V_dest_V, "[[/transaction]] \n");
		aesl_fh.write(WRAPC_STREAM_SIZE_OUT_p_dst_V_dest_V, wrapc_stream_size_out_p_dst_V_dest_V);

		// push back output stream: "_dst"
		for (int i = 0; i < aesl_tmp_4; i++)
		{
			_dst.write(aesl_tmp_3[i]);
		}

		CodeState = DELETE_CHAR_BUFFERS;
		// release memory allocation: "p_src_V_data_V"
		delete [] tvin_p_src_V_data_V;
		delete [] wrapc_stream_size_in_p_src_V_data_V;
		// release memory allocation: "p_src_V_keep_V"
		delete [] tvin_p_src_V_keep_V;
		delete [] wrapc_stream_size_in_p_src_V_keep_V;
		// release memory allocation: "p_src_V_strb_V"
		delete [] tvin_p_src_V_strb_V;
		delete [] wrapc_stream_size_in_p_src_V_strb_V;
		// release memory allocation: "p_src_V_user_V"
		delete [] tvin_p_src_V_user_V;
		delete [] wrapc_stream_size_in_p_src_V_user_V;
		// release memory allocation: "p_src_V_last_V"
		delete [] tvin_p_src_V_last_V;
		delete [] wrapc_stream_size_in_p_src_V_last_V;
		// release memory allocation: "p_src_V_id_V"
		delete [] tvin_p_src_V_id_V;
		delete [] wrapc_stream_size_in_p_src_V_id_V;
		// release memory allocation: "p_src_V_dest_V"
		delete [] tvin_p_src_V_dest_V;
		delete [] wrapc_stream_size_in_p_src_V_dest_V;
		// release memory allocation: "p_dst_V_data_V"
		delete [] tvout_p_dst_V_data_V;
		delete [] tvin_p_dst_V_data_V;
		delete [] wrapc_stream_size_out_p_dst_V_data_V;
		// release memory allocation: "p_dst_V_keep_V"
		delete [] tvout_p_dst_V_keep_V;
		delete [] tvin_p_dst_V_keep_V;
		delete [] wrapc_stream_size_out_p_dst_V_keep_V;
		// release memory allocation: "p_dst_V_strb_V"
		delete [] tvout_p_dst_V_strb_V;
		delete [] tvin_p_dst_V_strb_V;
		delete [] wrapc_stream_size_out_p_dst_V_strb_V;
		// release memory allocation: "p_dst_V_user_V"
		delete [] tvout_p_dst_V_user_V;
		delete [] tvin_p_dst_V_user_V;
		delete [] wrapc_stream_size_out_p_dst_V_user_V;
		// release memory allocation: "p_dst_V_last_V"
		delete [] tvout_p_dst_V_last_V;
		delete [] tvin_p_dst_V_last_V;
		delete [] wrapc_stream_size_out_p_dst_V_last_V;
		// release memory allocation: "p_dst_V_id_V"
		delete [] tvout_p_dst_V_id_V;
		delete [] tvin_p_dst_V_id_V;
		delete [] wrapc_stream_size_out_p_dst_V_id_V;
		// release memory allocation: "p_dst_V_dest_V"
		delete [] tvout_p_dst_V_dest_V;
		delete [] tvin_p_dst_V_dest_V;
		delete [] wrapc_stream_size_out_p_dst_V_dest_V;
		// release memory allocation: "src_height"
		delete [] tvin_src_height;
		// release memory allocation: "src_width"
		delete [] tvin_src_width;
		// release memory allocation: "dst_height"
		delete [] tvin_dst_height;
		// release memory allocation: "dst_width"
		delete [] tvin_dst_width;

		AESL_transaction++;

		tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);
	}
}

