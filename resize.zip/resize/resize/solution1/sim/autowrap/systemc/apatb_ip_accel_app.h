// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_ip_accel_app (
hls::stream<struct ap_axiu<24, 1, 1, 1 > > (&_src),
hls::stream<struct ap_axiu<24, 1, 1, 1 > > (&_dst),
int src_height,
int src_width,
int dst_height,
int dst_width);
