/***************************************************************************
Copyright (c) 2019, Xilinx, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software
without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

***************************************************************************/


#include "xf_headers.h"
#include "xf_resize_config.h"
int main(int argc, char** argv)
{

	if(argc != 2)
	{
		fprintf(stderr,"Invalid Number of Arguments!\nUsage:\n");
		fprintf(stderr,"<Executable Name> <input image path> \n");
		return -1;
	}
	cv::Mat ocv_ref;
	cv::Mat in_img,in_img1,diff;

	// reading in the color image
	in_img = cv::imread(argv[1]);
	if (in_img.data == NULL)
	{
		fprintf(stderr,"Cannot open image at %s\n", argv[1]);
		return 0;
	}
	uint16_t height = in_img.rows;
	uint16_t width = in_img.cols;
	uint16_t dst_height = int(in_img.rows*0.75);
	uint16_t dst_width = int(in_img.cols*0.75);
	// create memory for output images
	ocv_ref.create(dst_height,dst_width,CV_8UC3);
	diff.create(dst_height,dst_width,CV_8UC3);
	in_img1.create(dst_height,dst_width,CV_8UC3);


	///////////////// 	Opencv  Reference  ////////////////////////
	cv::resize(in_img, ocv_ref, cv::Size(dst_width, dst_height), cv::INTER_LINEAR);
	cv::imwrite("out_ocv.jpg", ocv_ref);

	AXI_STREAM _src,_dst;

	cvMat2AXIvideoxf<NPC1>(in_img, _src);
	ip_accel_app(_src, _dst,height,width, dst_height, dst_width);
	AXIvideo2cvMatxf<NPC1>(_dst, in_img1);
	/******xf::Mat format testing
	static xf::Mat<TYPE, SRC_HEIGHT, SRC_WIDTH, NPC1> imgInput(height,width);
	static xf::Mat<TYPE, DST_HEIGHT, DST_WIDTH, NPC1> imgOutput(dst_height,dst_width);

	imgInput.copyTo(in_img.data);
	resize_accel(imgInput, imgOutput);
	xf::imwrite("hls_out.jpg",imgOutput);

	// Compute absolute difference image
	xf::absDiff(ocv_ref, imgOutput, diff);******/



	cv::imwrite("hls.jpg", in_img1);
	//////////////////  Compute Absolute Difference ////////////////////

	cv::absdiff(ocv_ref, in_img1, diff);
	cv::imwrite("out_error.jpg", diff);

	// Find minimum and maximum differences.
		double minval=256,maxval=0;
	int cnt = 0;
	for (int i=0; i<dst_height; i++)
	{
		for(int j=0; j<dst_width; j++)
		{
			uchar v = diff.at<uchar>(i,j);
			if (v>0)
				cnt++;
			if (minval > v)
				minval = v;
			if (maxval < v)
				maxval = v;
		}
	}

	float err_per = 100.0*(float)cnt/(dst_height*dst_width);
	fprintf(stderr,"Minimum error in intensity = %f\n Maximum error in intensity = %f\n Percentage of pixels above error threshold = %f\n",minval,maxval,err_per);
	return 0;

}
